package com.ceobarros.historic.historic;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HistoricApplication {

	public static void main(String[] args) {
		SpringApplication.run(HistoricApplication.class, args);
	}
}
